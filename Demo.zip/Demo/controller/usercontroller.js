
const { User, Group, Message} = require('../model/userschema')
const jwt = require("jsonwebtoken");
const bcrypt = require('bcrypt')

const signup   =  async (req, res) => {
    const { username, password, email } = req.body;
  
    if (await User.findOne({ email })) {
      return res.status(400).json({ message: 'Email already exists.' });
    }
  
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword, email });
  
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully.' });
  };
  
 
  const login = async (req, res) => {
    const { email , password } = req.body;
    const user = await User.findOne({ email });
  
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }   
  
    const accessToken = jwt.sign({ userId: user._id, username: user.username }, JWT_SECRET);
    res.json({ accessToken });
  };
  
 
  const createGroup =  async (req, res) => {
    const { name, description, privacy } = req.body;
  
    const group = new Group({ name, description, privacy });
    await group.save()
  
    res.status(201).json(group);
  };
 
const addmember =  async (req, res) => {
    const { groupId } = req.params;
    const { userId } = req.body;
  
    const group = await Group.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found.' });
    }
  
    group.members.push(userId);
    await group.save();
    res.status(200).json({ message: 'User added to group.' });
  };

 const sendmsg =  async (req, res) => {
    const { groupId } = req.params;
    const { text, type } = req.body;
  
    const group = await Group.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found.' });
    }
  
    const message = new Message({
      text,
      type,
      user: req.user.userId, 
      group: groupId,
    });
  
    await message.save();
    res.status(201).json(message);
  };    
  

const getmsg = async (req, res) => {
    const { groupId } = req.params;
  
    const group = await Group.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found.' });
    }
  
    const messages = await Message.find({ group: groupId, archived: false }).populate('user', 'username');
    res.json(messages);
  };


  module.exports = {
    signup,
    login,
    createGroup,
    addmember,
    sendmsg,
    getmsg
  };
  