const {User,Permission} = require('../model/userschema')
require("dotenv").config();

const authenticateJWT = (req, res, next) => {
    const token = req.headers['authorization'].split(' ')[1];
  
    if (!token) {
      return res.status(403).json({ message: 'Access denied. No token provided.' });
    }
  
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ message: 'Invalid or expired token.' });
      }
      req.user = user;
      next();
    });
  }
  
  
 const checkPermission =   (permissionName)  => {
    return async (req, res, next) => {
      const user = await User.findById(req.user.userId).populate('roles');
      const roles = user.roles;
  
      for (const role of roles) {
        const permissions = await Permission.find({ _id: { $in: role.permissions } });
        if (permissions.some(permission => permission.name === permissionName)) {
          return next(); 
        }
      }
      return res.status(403).json({ message: 'Permission denied.' });
    };
  }


  module.exports = {
    checkPermission,authenticateJWT
  }