
const express = require("express");
const router = express.Router();
const {checkPermission,authenticateJWT} = require('../middleware/authmiddleware')
const { login, signup,createGroup , addmember , sendmsg , getmsg} = require("../controller/usercontroller");

router.post("/register", signup);
router.post("/login", login);
router.post('/groups', authenticateJWT, checkPermission('create_group' ),createGroup)
router.post('/groups/:groupId/members', authenticateJWT, checkPermission('add_member'),addmember)
router.post('/groups/:groupId/messages', authenticateJWT,sendmsg)
router.get('/groups/:groupId/messages', authenticateJWT, getmsg )

module.exports = router