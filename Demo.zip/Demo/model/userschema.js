const mongoose = require('mongoose');

// Define the User Schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, },
  password: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  profile: { type: String, default: "default_profile.png" }, 
  roles: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Role' }],
  groups: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Group' }], 
});

// Define the Group Schema
const groupSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String },
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], 
  messages: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Message' }],
  privacy: { type: String, enum: ['public', 'private'], default: 'public' },
  permissions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Permission' }], 
});

// Define the Message Schema
const messageSchema = new mongoose.Schema({
  text: { type: String },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  group: { type: mongoose.Schema.Types.ObjectId, ref: 'Group', required: true },
  type: { type: String, enum: ['text', 'image', 'file'], default: 'text' },
  createdAt: { type: Date, default: Date.now },
  archived: { type: Boolean, default: false }, 
});

// Define the Role Schema
const roleSchema = new mongoose.Schema({
  name: { type: String, required: true, enum: ['admin', 'moderator', 'member'] },
  permissions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Permission' }],
});

// Define the Permission Schema
const permissionSchema = new mongoose.Schema({
  name: { type: String, required: true },
  action: { type: String, required: true },
});

// Models
const User = mongoose.model('User', userSchema);
const Group = mongoose.model('Group', groupSchema);
const Message = mongoose.model('Message', messageSchema);
const Role = mongoose.model('Role', roleSchema);
const Permission = mongoose.model('Permission', permissionSchema);

module.exports = { User, Group, Message, Role, Permission };
